from network import LoRa
from machine import Timer, UART
import time
import socket

### Flash 1

class Sample_sendr:
    def __init__(self):
        self.rssi_timer = Timer.Alarm(self.get_rssi, 0.001, periodic=True)
        self.stop_flag = False

    def get_rssi(self, alarm):
        print(lora.signal_strength())
        if self.stop_flag:
            alarm.cancel()

ch = Timer.Chrono()
lora = LoRa(mode=LoRa.LORA, region=LoRa.US915, tx_power=5)
# sock = socket.socket(socket.AF_LORA, socket.SOCK_RAW)
# sock.setblocking(True)
sendr = Sample_sendr()